// import CompA from "../components/compA";
// import MultiTweet from "../components/tweet/MultiplyTweet.js";
import Todo from '../components/todo/index.js'

const routes = [
  
    {
        component: <Todo />,
        path: "/todolist"
    }, 
]

export default routes;